<?php
/* 
-----------------
Language: Spanish
-----------------
*/

$lang = array();

$lang['PAGE_TITLE'] = 'T�tulo de la p�gina de mi sitio web';
$lang['HEADER_TITLE'] = 'Mi sitio web de la cabecera t�tulo';
$lang['SITE_NAME'] = 'Mi Sitio Web';
$lang['SLOGAN'] = 'Mi lema aqu�';
$lang['HEADING'] = 'T�tulo';

// Menu

$lang['MENU_HOME'] = 'Inicio';
$lang['MENU_ABOUT_US'] = 'Sobre Nosotros';
$lang['MENU_OUR_PRODUCTS'] = 'Nuestros productos';
$lang['MENU_CONTACT_US'] = 'Cont�ctenos';
$lang['MENU_ADVERTISE'] = 'Publicidad';
$lang['MENU_SITE_MAP'] = 'Mapa del Sitio';
?>