<?php
/* 
------------------
Language: English
------------------
*/

$lang = array();

$lang['PAGE_TITLE'] = 'My website page title';
$lang['HEADER_TITLE'] = 'My website header title';
$lang['SITE_NAME'] = 'My Website';
$lang['SLOGAN'] = 'My slogan here';
$lang['HEADING'] = 'Heading';

// Menu

$lang['MENU_HOME'] = 'Home';
$lang['MENU_ABOUT_US'] = 'About Us';
$lang['MENU_OUR_PRODUCTS'] = 'Our products';
$lang['MENU_CONTACT_US'] = 'Contact Us';
$lang['MENU_ADVERTISE'] = 'Advertise';
$lang['MENU_SITE_MAP'] = 'Site Map';
?>